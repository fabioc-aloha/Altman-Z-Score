# models package for financial_metrics and related dataclasses
