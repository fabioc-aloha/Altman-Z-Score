from typing import Optional

from .constants import MODEL_COEFFICIENTS

def determine_zscore_model(profile):
    """
    Select the correct Altman Z-Score model based on company profile (industry, SIC, maturity, public/private, region).
    Args:
        profile: CompanyProfile object with industry, sic, is_public, is_emerging_market, maturity, etc.
    Returns:
        model_key (str): Key for MODEL_COEFFICIENTS/Z_SCORE_THRESHOLDS
    """
    # Prefer SIC-based override if available
    sic = getattr(profile, "sic", None) or None
    if sic:
        sic_key = f"sic_{sic}"
        if sic_key in MODEL_COEFFICIENTS:
            return sic_key
    # Use region
    if getattr(profile, "is_emerging_market", False):
        return "em"
    # Use maturity if available
    maturity = getattr(profile, "maturity", None)
    is_public = getattr(profile, "is_public", True)
    industry = (getattr(profile, "industry", "") or "").lower()
    # Map industry to model
    if industry in ["manufacturing", "hardware", "industrial"]:
        return "original" if is_public else "private"
    if industry in ["service", "software", "tech", "technology"]:
        return "service" if is_public else "private"
    # Use maturity for override
    if maturity:
        if maturity == "early-stage":
            return "private"
        if maturity == "growth":
            return "private" if not is_public else "original"
        if maturity == "mature":
            return "original" if is_public else "private"
    # Fallback
    return "original"

def select_zscore_model(sic: Optional[int], maturity: Optional[str], is_public: Optional[bool] = True) -> str:
    """
    Select the correct Altman Z-Score model key based on SIC, maturity, and public/private status.
    Follows robust, literature-aligned logic (see ModelSelection.md).
    Args:
        sic (Optional[int]): SIC code (int or str convertible to int)
        maturity (Optional[str]): 'public', 'private', 'emerging', etc.
        is_public (Optional[bool]): True if public, False if private. Defaults to True.
    Returns:
        str: Model key for MODEL_COEFFICIENTS/Z_SCORE_THRESHOLDS
    """
    # 1. Check for explicit per-SIC override
    try:
        sic_int = int(sic) if sic is not None else None
    except Exception:
        sic_int = None
    sic_key = f"sic_{sic_int}" if sic_int is not None else None
    if sic_key and sic_key in MODEL_COEFFICIENTS:
        return sic_key

    # 2. Handle 'emerging' (or any EM-specific flag) BEFORE any private check
    if maturity and str(maturity).lower() == "emerging":
        return "emerging"

    # 3. If the firm is flagged as 'private', split by SIC to pick private-manufacturing vs. private-service
    if maturity and str(maturity).lower() == "private":
        if sic_int is not None:
            if 2000 <= sic_int <= 3999:
                return "private_mfg"
            if ((4000 <= sic_int <= 4999) or
                (3570 <= sic_int <= 3579) or (3670 <= sic_int <= 3679) or (7370 <= sic_int <= 7379) or
                (6000 <= sic_int <= 6999) or
                (7000 <= sic_int <= 8999)):
                return "private_service"
        # If private but doesn't fall into any known SIC range above, default to private_mfg
        return "private_mfg"

    # 4. At this point, the firm is not 'emerging' and not 'private', so treat as public
    if sic_int is not None:
        if 2000 <= sic_int <= 3999:
            return "original"
        # Airlines and all transportation/service: SIC 4000–4999 should use public_service
        if 4000 <= sic_int <= 4999:
            return "public_service"
        if (3570 <= sic_int <= 3579) or (3670 <= sic_int <= 3679) or (7370 <= sic_int <= 7379):
            return "public_service"
        if 6000 <= sic_int <= 6999:
            return "public_service"
        if 7000 <= sic_int <= 8999:
            return "public_service"
    # 5. Fallback for any public company that didn't match a SIC range
    return "original"

def select_zscore_model_by_sic(sic_code: str, is_public: bool = True, maturity: Optional[str] = None) -> str:
    """
    Map SIC code to the correct Altman Z-Score model type, using constants.py for overrides.
    Args:
        sic_code (str): SIC code as string or int
        is_public (bool): Whether the company is public
        maturity (Optional[str]): Optional maturity string (e.g., 'private', 'emerging')
    Returns:
        str: Model type key for constants.py
    """
    try:
        sic = int(str(sic_code))
    except Exception:
        return "original"  # fallback to original if SIC is invalid
    sic_key = f"sic_{sic}"
    if sic_key in MODEL_COEFFICIENTS:
        return sic_key
    if maturity and str(maturity).lower() in ["private", "emerging", "early-stage", "growth"]:
        return "private"
    if 2000 <= sic <= 3999:
        return "original" if is_public else "private"
    # Airlines and all transportation/service: SIC 4000–4999 should use Zʺ (service) model
    if 4000 <= sic <= 4999:
        return "service" if is_public else "private"
    if (3570 <= sic <= 3579) or (3670 <= sic <= 3679) or (7370 <= sic <= 7379):
        return "service" if is_public else "private"
    if 6000 <= sic <= 6999:
        return "service" if is_public else "private"
    if 7000 <= sic <= 8999:
        return "service" if is_public else "private"
    return "original"  # fallback
