# Centralized constants for Altman Z-Score models
from decimal import Decimal
from typing import Dict, List

# Direct field mappings for data fetching (field name variations by source)
FIELD_MAPPING = {
    'total_assets': ['Total Assets', 'Assets', 'AssetsTotal'],
    'current_assets': ['Current Assets', 'AssetsCurrent'],
    'current_liabilities': ['Current Liabilities', 'LiabilitiesCurrent'],
    'retained_earnings': ['Retained Earnings', 'RetainedEarnings'],
    'total_liabilities': ['Total Liabilities Net Minority Interest', 'Total Liabilities', 'Liabilities'],
    'book_value_equity': ['Common Stock Equity', 'Stockholders Equity', 'Total Equity Gross Minority Interest'],
    'ebit': ['EBIT', 'Operating Income', 'OperatingIncome'],
    'sales': ['Total Revenue', 'Revenues', 'Sales', 'Revenue', 'Operating Revenue']
}

# Required fields per model type (specifies which fields must be present in data)
MODEL_FIELDS: Dict[str, List[str]] = {
    "original": [
        "total_assets",
        "current_assets",
        "current_liabilities",
        "retained_earnings",
        "total_liabilities",
        "book_value_equity",
        "ebit",
        "sales"
    ],
    "private": [
        "total_assets",
        "current_assets",
        "current_liabilities",
        "retained_earnings",
        "total_liabilities",
        "book_value_equity",
        "ebit",
        "sales"
    ],
    "public": [
        "total_assets",
        "current_assets",
        "current_liabilities",
        "retained_earnings",
        "total_liabilities",
        "market_value_equity",
        "ebit",
        "sales"
    ],
    # For public non-manufacturing (Zʺ): use market_value_equity for X4
    "service": [
        "total_assets",
        "current_assets",
        "current_liabilities",
        "retained_earnings",
        "total_liabilities",
        "market_value_equity",
        "ebit",
        "sales"
    ],
    # For private non-manufacturing: use book_value_equity for X4
    "private_service": [
        "total_assets",
        "current_assets",
        "current_liabilities",
        "retained_earnings",
        "total_liabilities",
        "book_value_equity",
        "ebit",
        "sales"
    ],
    # Alias for clarity
    "public_service": [
        "total_assets",
        "current_assets",
        "current_liabilities",
        "retained_earnings",
        "total_liabilities",
        "market_value_equity",
        "ebit",
        "sales"
    ],
    "emerging": [
        "total_assets",
        "current_assets",
        "current_liabilities",
        "retained_earnings", 
        "total_liabilities",
        "book_value_equity",
        "ebit",
        "sales"
    ]
}

# --- Metadata for traceability ---
MODEL_METADATA = {
    "original": {
        "version": "2025-05-29",
        "source": "Altman 1968, 2000, 2017; WRDS/Compustat; see altmans.md",
        "notes": "Classic public manufacturing model.",
    },
    "private": {
        "version": "2025-05-29",
        "source": "Altman 2000; see altmans.md",
        "notes": "Private firm model.",
    },
    "service": {
        "version": "2025-05-29",
        "source": "Altman 1993; see altmans.md",
        "notes": "Service/Non-manufacturing model.",
    },
    "tech": {
        "version": "2025-05-29",
        "source": "Altman 1993; see altmans.md",
        "notes": "Tech companies use the service/non-manufacturing model.",
    },
    "em": {
        "version": "2025-05-29",
        "source": "Altman 2017; see altmans.md",
        "notes": "Emerging Markets model.",
    },
    "sic_2834": {
        "version": "2025-05-29",
        "source": "Example WRDS/Compustat calibration; update as needed.",
        "notes": "Pharma (SIC 2834) override.",
    },
    # Add more as needed
}

# --- Model coefficients by type (can be extended per SIC/industry) ---
MODEL_COEFFICIENTS: Dict[str, Dict[str, Decimal]] = {
    "original": {
        "A": Decimal("1.2"),
        "B": Decimal("1.4"),
        "C": Decimal("3.3"),
        "D": Decimal("0.6"),
        "E": Decimal("1.0"),
    },
    "private": {
        "A": Decimal("0.717"),
        "B": Decimal("0.847"),
        "C": Decimal("3.107"),
        "D": Decimal("0.420"),
        "E": Decimal("0.998"),
    },
    "private_mfg": {
        # Altman Z'-Score (private manufacturing, five-factor, book equity)
        "A": Decimal("0.717"),
        "B": Decimal("0.847"),
        "C": Decimal("3.107"),
        "D": Decimal("0.420"),
        "E": Decimal("0.998"),
    },
    "private_service": {
        # Altman Z''-Score (private non-manufacturing/service, four-factor, book equity)
        "A": Decimal("6.56"),
        "B": Decimal("3.26"),
        "C": Decimal("6.72"),
        "D": Decimal("1.05"),
        "E": Decimal("0.0"),
    },
    "public_service": {
        # Altman Z''-Score (public non-manufacturing/service, four-factor, market equity)
        "A": Decimal("6.56"),
        "B": Decimal("3.26"),
        "C": Decimal("6.72"),
        "D": Decimal("1.05"),
        "E": Decimal("0.0"),
    },
    "service": {
        "A": Decimal("6.56"),
        "B": Decimal("3.26"),
        "C": Decimal("6.72"),
        "D": Decimal("1.05"),
        "E": Decimal("0.0"),
    },
    "tech": {  # Alias for service/non-manufacturing model
        "A": Decimal("6.56"),
        "B": Decimal("3.26"),
        "C": Decimal("6.72"),
        "D": Decimal("1.05"),
        "E": Decimal("0.0"),
    },
    "em": {
        "A": Decimal("3.25"),
        "B": Decimal("6.56"),
        "C": Decimal("6.72"),
        "D": Decimal("1.05"),
        "E": Decimal("0.0"),
    },
    "emerging": {
        # Altman Emerging Markets model
        "A": Decimal("3.25"),
        "B": Decimal("6.56"),
        "C": Decimal("6.72"),
        "D": Decimal("1.05"),
        "E": Decimal("0.0"),
    },
    # Example: per-industry override (SIC 2834 = Pharma)
    "sic_2834": {
        "A": Decimal("1.1"),
        "B": Decimal("1.5"),
        "C": Decimal("3.0"),
        "D": Decimal("0.7"),
        "E": Decimal("1.2"),
    },
    # Add more SIC/industry-specific as needed
}

# --- Z-Score thresholds by model (can be extended per industry/region) ---
Z_SCORE_THRESHOLDS: Dict[str, Dict[str, Decimal]] = {
    "original": {"safe": Decimal("2.99"), "grey": Decimal("1.81"), "distress": Decimal("1.81")},
    "private": {"safe": Decimal("2.9"), "grey": Decimal("1.23"), "distress": Decimal("1.23")},
    "private_mfg": {"safe": Decimal("2.9"), "grey": Decimal("1.23"), "distress": Decimal("1.23")},
    "private_service": {"safe": Decimal("2.6"), "grey": Decimal("1.1"), "distress": Decimal("1.1")},
    # Altman 1995 public Zʺ (service/non-manufacturing, public):
    "service": {"safe": Decimal("2.90"), "grey": Decimal("1.23"), "distress": Decimal("1.23")},
    "tech": {"safe": Decimal("2.90"), "grey": Decimal("1.23"), "distress": Decimal("1.23")},
    # Optionally, add a public_service alias for clarity
    "public_service": {"safe": Decimal("2.90"), "grey": Decimal("1.23"), "distress": Decimal("1.23")},
    "em": {"safe": Decimal("2.6"), "grey": Decimal("1.1"), "distress": Decimal("1.1")},
    "emerging": {"safe": Decimal("2.6"), "grey": Decimal("1.1"), "distress": Decimal("1.1")},
    # Example: per-industry override
    "sic_2834": {"safe": Decimal("3.1"), "grey": Decimal("2.0"), "distress": Decimal("1.5")},
    # Add more SIC/industry-specific as needed
}

# Clarification: For 'service' (public), X4 = market value of equity / total liabilities.
# For 'private_service', X4 = book value of equity / total liabilities.

# --- Typical size/leverage ranges for warnings (example values, update as needed) ---
SIZE_WARNINGS = {
    "min_assets": Decimal("1000000"),  # $1M
    "max_assets": Decimal("10000000000"),  # $10B
    "max_leverage": Decimal("10.0"),  # Total Liabilities / Total Assets
}

# --- Emerging Markets (EM) country/region codes (ISO2/3, can be expanded) ---
EMERGING_MARKETS = [
    "CN",
    "IN",
    "BR",
    "RU",
    "ZA",
    "MX",
    "ID",
    "TR",
    "PL",
    "TH",
    "PH",
    "EG",
    "NG",
    "PK",
    "VN",
    "AR",
    "CO",
    "MY",
    "CL",
    "PE",
]

# --- Region/EM Model Aliases (for international support) ---
MODEL_ALIASES = {
    "EM": "em",
    "EMERGING": "em",
    "EU": "service",
    "ASIA": "service",
    # Add more as needed
}

# --- Calibration update process metadata ---
CALIBRATION_UPDATE = {
    "last_update": "2025-05-29",
    "update_notes": "Initial v2.2 structure. See altmans.md for process.",
    "update_source": "WRDS/Compustat, Altman literature, open data.",
}

# All future model changes must be made in this file and referenced throughout the codebase.
